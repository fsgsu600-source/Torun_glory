async function login(){
  const res = await fetch('http://localhost:5000/api/auth/login',{
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body:JSON.stringify({
      email:email.value,
      password:password.value
    })
  });

  const data = await res.json();
  localStorage.setItem('token',data.token);
  window.location='dashboard.html';
}

async function order(){
  await fetch('http://localhost:5000/api/orders',{
    method:'POST',
    headers:{
      'Content-Type':'application/json',
      'Authorization':localStorage.getItem('token')
    },
    body:JSON.stringify({
      guildId:guildId.value,
      amount:amount.value
    })
  });

  alert('Order placed');
}