const jwt = require('jsonwebtoken');

module.exports = (req,res,next)=>{
  const token = req.headers.authorization;
  if(!token) return res.sendStatus(401);

  try{
    const data = jwt.verify(token,'secret');
    req.user = data;
    next();
  }catch(err){
    res.sendStatus(403);
  }
};