const router = require('express').Router();
const Order = require('../models/Order');
const auth = require('../middleware/auth');

router.post('/', auth, async (req,res)=>{
  const order = await Order.create({
    userId:req.user.id,
    guildId:req.body.guildId,
    amount:req.body.amount
  });
  res.json(order);
});

router.get('/', auth, async (req,res)=>{
  const orders = await Order.find({userId:req.user.id});
  res.json(orders);
});

module.exports = router;